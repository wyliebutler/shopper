const Database = require('better-sqlite3');
const path = require('path');

// Use a volume path in production, or local file in dev
const dbPath = process.env.DB_PATH || path.join(__dirname, 'todo.db');
const db = new Database(dbPath);

// Create table
db.exec(`
  CREATE TABLE IF NOT EXISTS items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    text TEXT NOT NULL,
    completed INTEGER DEFAULT 0,
    image_path TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )
`);

// Migration: Add image_path column if it doesn't exist (for existing DBs)
try {
    db.exec('ALTER TABLE items ADD COLUMN image_path TEXT');
} catch (error) {
    // Column likely already exists, ignore
}

module.exports = db;
