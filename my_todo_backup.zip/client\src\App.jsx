import { useState, useEffect, useRef } from 'react'
import { Plus, Trash2, Check, X, Camera, Pencil, LogOut, Mic, ScanBarcode } from 'lucide-react'
import Login from './Login'
import BarcodeScanner from './BarcodeScanner'

function App() {
    const [items, setItems] = useState([])
    const [inputValue, setInputValue] = useState('')
    const [loading, setLoading] = useState(true)
    const [uploading, setUploading] = useState(false)
    const [editingId, setEditingId] = useState(null)
    const [editText, setEditText] = useState('')
    const [token, setToken] = useState(localStorage.getItem('todo_token'))
    const [isListening, setIsListening] = useState(false)
    const [showScanner, setShowScanner] = useState(false)
    const fileInputRef = useRef(null)

    useEffect(() => {
        if (token) {
            fetchItems()
        }
    }, [token])

    const vibrate = (pattern) => {
        if (navigator.vibrate) {
            navigator.vibrate(pattern)
        }
    }

    const handleLogin = (newToken) => {
        localStorage.setItem('todo_token', newToken)
        setToken(newToken)
    }

    const handleLogout = () => {
        localStorage.removeItem('todo_token')
        setToken(null)
        setItems([])
    }

    const fetchItems = async () => {
        try {
            const res = await fetch('/api/items', {
                headers: { 'Authorization': `Bearer ${token}` }
            })
            if (res.ok) {
                const data = await res.json()
                setItems(data)
            }
        } catch (error) {
            console.error('Error fetching items:', error)
        } finally {
            setLoading(false)
        }
    }

    const createNewItem = async (text) => {
        if (!text.trim()) return false
        try {
            const res = await fetch('/api/items', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({ text: text })
            })
            if (res.ok) {
                const newItem = await res.json()
                setItems([newItem, ...items])
                vibrate(50) // Success buzz
                return true
            }
        } catch (error) {
            console.error('Error adding item:', error)
        }
        return false
    }

    const addItem = async (e) => {
        e.preventDefault()
        const success = await createNewItem(inputValue)
        if (success) setInputValue('')
    }

    const handleImageUpload = async (e) => {
        const file = e.target.files[0]
        if (!file) return

        setUploading(true)
        const formData = new FormData()
        formData.append('image', file)

        try {
            const res = await fetch('/api/upload', {
                method: 'POST',
                headers: { 'Authorization': `Bearer ${token}` },
                body: formData
            })
            if (res.ok) {
                const newItem = await res.json()
                setItems([newItem, ...items])
            } else {
                console.error('Upload failed')
            }
        } catch (error) {
            console.error('Error uploading image:', error)
        } finally {
            setUploading(false)
            if (fileInputRef.current) {
                fileInputRef.current.value = ''
            }
        }
    }

    const toggleComplete = async (id, currentStatus) => {
        try {
            const res = await fetch(`/api/items/${id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({ completed: !currentStatus })
            })
            if (res.ok) {
                setItems(items.map(item =>
                    item.id === id ? { ...item, completed: !item.completed } : item
                ))
                vibrate(10) // Light tick
            }
        } catch (error) {
            console.error('Error updating item:', error)
        }
    }

    const deleteItem = async (id) => {
        try {
            const res = await fetch(`/api/items/${id}`, {
                method: 'DELETE',
                headers: { 'Authorization': `Bearer ${token}` }
            })
            if (res.ok) {
                setItems(items.filter(item => item.id !== id))
                vibrate([20, 50, 20]) // Double buzz for delete
            }
        } catch (error) {
            console.error('Error deleting item:', error)
        }
    }

    const startEdit = (item) => {
        setEditingId(item.id)
        setEditText(item.text)
    }

    const cancelEdit = () => {
        setEditingId(null)
        setEditText('')
    }

    const saveEdit = async (id) => {
        if (!editText.trim()) return

        try {
            const res = await fetch(`/api/items/${id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({ text: editText })
            })
            if (res.ok) {
                setItems(items.map(item =>
                    item.id === id ? { ...item, text: editText } : item
                ))
                setEditingId(null)
                setEditText('')
            }
        } catch (error) {
            console.error('Error updating item text:', error)
        }
    }

    const clearCompleted = async () => {
        try {
            const res = await fetch('/api/items/completed', {
                method: 'DELETE',
                headers: { 'Authorization': `Bearer ${token}` }
            })
            if (res.ok) {
                setItems(items.filter(item => !item.completed))
                vibrate(50)
            }
        } catch (error) {
            console.error('Error clearing completed items:', error)
        }
    }

    const handleVoiceInput = () => {
        if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
            alert('Voice input is not supported in this browser.')
            return
        }

        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
        const recognition = new SpeechRecognition()

        recognition.continuous = false
        recognition.interimResults = false
        recognition.lang = 'en-US'

        recognition.onstart = () => {
            setIsListening(true)
        }

        recognition.onend = () => {
            setIsListening(false)
        }

        recognition.onresult = (event) => {
            const transcript = event.results[0][0].transcript
            setInputValue(transcript)

            // Auto-submit after a 1 second pause/delay to let user see what was heard
            setTimeout(async () => {
                const success = await createNewItem(transcript)
                if (success) setInputValue('')
            }, 1000)
        }

        recognition.start()
    }

    const handleBarcodeDetected = async (code) => {
        setShowScanner(false)
        // Optimistic UI: Show loading or just the code first?
        // Let's try to look it up
        try {
            const res = await fetch(`https://world.openfoodfacts.org/api/v0/product/${code}.json`)
            const data = await res.json()

            let productName = code // Fallback to code if not found
            if (data.status === 1 && data.product && data.product.product_name) {
                productName = data.product.product_name
            }

            await createNewItem(productName)
        } catch (error) {
            console.error("Error looking up barcode:", error)
            await createNewItem(code) // Fallback to adding just the code
        }
    }

    if (!token) {
        return <Login onLogin={handleLogin} />
    }

    return (
        <div className="glass-container">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
                <h1 style={{ margin: 0 }}>Shopping List</h1>
                <button onClick={handleLogout} className="btn-icon" title="Logout" style={{ opacity: 0.7 }}>
                    <LogOut size={20} />
                </button>
            </div>

            <form onSubmit={addItem}>
                <div className="input-row top">
                    <input
                        type="text"
                        value={inputValue}
                        onChange={(e) => setInputValue(e.target.value)}
                        placeholder="Add a new item..."
                        disabled={uploading}
                    />
                    <button type="submit" className="btn-primary" disabled={uploading}>
                        <Plus size={20} />
                    </button>
                </div>

                <div className="input-row bottom">
                    <input
                        type="file"
                        accept="image/*"
                        capture="environment"
                        ref={fileInputRef}
                        onChange={handleImageUpload}
                        style={{ display: 'none' }}
                    />

                    <button
                        type="button"
                        className="btn-primary"
                        onClick={() => fileInputRef.current.click()}
                        disabled={uploading}
                        style={{ background: '#e0e7ff', color: '#4f46e5' }}
                    >
                        {uploading ? <div className="spinner">...</div> : <Camera size={20} />}
                    </button>

                    <button
                        type="button"
                        className="btn-primary"
                        onClick={handleVoiceInput}
                        disabled={uploading || isListening}
                        style={{ background: isListening ? '#fee2e2' : '#f3f4f6', color: isListening ? '#ef4444' : '#4b5563' }}
                    >
                        <Mic size={20} />
                    </button>

                    <button
                        type="button"
                        className="btn-primary"
                        onClick={() => setShowScanner(true)}
                        disabled={uploading || isListening}
                        style={{ background: '#f3f4f6', color: '#4b5563' }}
                    >
                        <ScanBarcode size={20} />
                    </button>
                </div>
            </form>

            {loading ? (
                <p style={{ textAlign: 'center', opacity: 0.7 }}>Loading...</p>
            ) : (
                <>
                    <ul className="list">
                        {items.map(item => (
                            <li key={item.id} className={`item ${item.completed ? 'completed' : ''}`}>

                                {item.image_path && (
                                    <img
                                        src={item.image_path}
                                        alt="Item"
                                        style={{
                                            width: '80px',
                                            height: '80px',
                                            borderRadius: '8px',
                                            objectFit: 'cover',
                                            marginRight: '12px',
                                            border: '1px solid rgba(255,255,255,0.3)'
                                        }}
                                    />
                                )}

                                {editingId === item.id ? (
                                    <div style={{ flex: 1, display: 'flex', gap: '8px', marginRight: '8px' }}>
                                        <input
                                            type="text"
                                            value={editText}
                                            onChange={(e) => setEditText(e.target.value)}
                                            autoFocus
                                            style={{ padding: '8px', fontSize: '0.9rem' }}
                                        />
                                        <button onClick={() => saveEdit(item.id)} className="btn-icon" style={{ color: '#4ade80' }}>
                                            <Check size={18} />
                                        </button>
                                        <button onClick={cancelEdit} className="btn-icon" style={{ color: '#f87171' }}>
                                            <X size={18} />
                                        </button>
                                    </div>
                                ) : (
                                    <>
                                        <span onClick={() => toggleComplete(item.id, item.completed)} style={{ cursor: 'pointer', flex: 1 }}>
                                            {item.text}
                                        </span>
                                        <div className="item-actions">
                                            <button
                                                onClick={() => startEdit(item)}
                                                className="btn-icon"
                                                title="Edit"
                                            >
                                                <Pencil size={18} />
                                            </button>
                                            <button
                                                onClick={() => toggleComplete(item.id, item.completed)}
                                                className="btn-icon"
                                                title={item.completed ? "Mark incomplete" : "Mark complete"}
                                            >
                                                {item.completed ? <X size={18} /> : <Check size={18} />}
                                            </button>
                                            <button
                                                onClick={() => deleteItem(item.id)}
                                                className="btn-icon btn-delete"
                                                title="Delete"
                                            >
                                                <Trash2 size={18} />
                                            </button>
                                        </div>
                                    </>
                                )}
                            </li>
                        ))}
                        {items.length === 0 && (
                            <p style={{ textAlign: 'center', opacity: 0.5, fontStyle: 'italic' }}>
                                Your list is empty. Time to shop!
                            </p>
                        )}
                    </ul>
                    {items.some(item => item.completed) && (
                        <button
                            onClick={clearCompleted}
                            style={{
                                width: '100%',
                                marginTop: '1rem',
                                padding: '10px',
                                background: 'rgba(255, 59, 48, 0.1)',
                                color: '#ff3b30',
                                border: '1px solid rgba(255, 59, 48, 0.2)',
                                borderRadius: '12px',
                                cursor: 'pointer',
                                fontWeight: '600',
                                transition: 'all 0.2s ease'
                            }}
                        >
                            Clear Completed
                        </button>
                    )}
                </>
            )}

            {showScanner && (
                <BarcodeScanner
                    onScan={handleBarcodeDetected}
                    onClose={() => setShowScanner(false)}
                />
            )}
        </div>
    )
}

export default App
