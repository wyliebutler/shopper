const express = require('express');
const cors = require('cors');
const path = require('path');
const multer = require('multer');
const fs = require('fs');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const jwt = require('jsonwebtoken');
require('dotenv').config();

const db = require('./db');

const app = express();
const PORT = process.env.PORT || 9001;
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key';
const APP_PASSWORD = process.env.APP_PASSWORD;

// Initialize Gemini
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

// Middleware
app.use(cors());
app.use(express.json());

// Serve static files from the React app
app.use(express.static(path.join(__dirname, '../client/dist')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Configure Multer for image uploads
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        const uploadDir = path.join(__dirname, 'uploads');
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir, { recursive: true });
        }
        cb(null, uploadDir);
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + '-' + file.originalname);
    }
});
const upload = multer({ storage: storage });

// Auth Middleware
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) return res.sendStatus(401);

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) return res.sendStatus(403);
        req.user = user;
        next();
    });
};

// API Routes

// Login
app.post('/api/login', (req, res) => {
    const { password } = req.body;
    if (password === APP_PASSWORD) {
        // Token valid for 30 days
        const token = jwt.sign({ user: 'family' }, JWT_SECRET, { expiresIn: '30d' });
        res.json({ token });
    } else {
        res.status(401).json({ error: 'Invalid password' });
    }
});

// Get all items
app.get('/api/items', authenticateToken, (req, res) => {
    try {
        const stmt = db.prepare('SELECT * FROM items ORDER BY created_at DESC');
        const items = stmt.all();
        res.json(items);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Add a new item
app.post('/api/items', authenticateToken, (req, res) => {
    const { text } = req.body;
    try {
        const stmt = db.prepare('INSERT INTO items (text) VALUES (?)');
        const info = stmt.run(text);
        const newItem = db.prepare('SELECT * FROM items WHERE id = ?').get(info.lastInsertRowid);
        res.json(newItem);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Upload image and identify item
app.post('/api/upload', authenticateToken, upload.single('image'), async (req, res) => {
    if (!req.file) {
        return res.status(400).json({ error: 'No image uploaded' });
    }

    const imagePath = `/uploads/${req.file.filename}`;
    let itemText = 'New Item from Image';

    // Try to identify with Gemini
    console.log("Attempting AI identification...");
    if (process.env.GEMINI_API_KEY) {
        console.log("API Key found (length: " + process.env.GEMINI_API_KEY.length + ")");
        try {
            // Use specific model version
            const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash" });
            const imagePathLocal = req.file.path;
            const imageData = fs.readFileSync(imagePathLocal);
            const imageBase64 = imageData.toString('base64');

            const prompt = "Identify the main object in this image. Return ONLY the name of the object, nothing else. Keep it short (e.g., 'Apple', 'Milk Carton').";

            console.log("Sending request to Gemini (model: gemini-2.0-flash)...");
            const result = await model.generateContent([
                prompt,
                {
                    inlineData: {
                        data: imageBase64,
                        mimeType: req.file.mimetype
                    }
                }
            ]);
            const response = await result.response;
            const text = response.text();
            console.log("Gemini response:", text);

            if (text) {
                itemText = text.trim();
            }
        } catch (error) {
            console.error("Gemini API Error Details:", error);
            // Fallback to default text if AI fails
        }
    } else {
        console.log("No GEMINI_API_KEY found in environment variables");
    }

    try {
        const stmt = db.prepare('INSERT INTO items (text, image_path) VALUES (?, ?)');
        const info = stmt.run(itemText, imagePath);
        const newItem = db.prepare('SELECT * FROM items WHERE id = ?').get(info.lastInsertRowid);
        res.json(newItem);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Update item (completed status or text)
app.put('/api/items/:id', authenticateToken, (req, res) => {
    const { completed, text } = req.body;
    const { id } = req.params;
    try {
        if (text !== undefined) {
            const stmt = db.prepare('UPDATE items SET text = ? WHERE id = ?');
            stmt.run(text, id);
        }
        if (completed !== undefined) {
            const stmt = db.prepare('UPDATE items SET completed = ? WHERE id = ?');
            stmt.run(completed ? 1 : 0, id);
        }
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Delete all completed items
app.delete('/api/items/completed', authenticateToken, (req, res) => {
    try {
        const stmt = db.prepare('DELETE FROM items WHERE completed = 1');
        const info = stmt.run();
        res.json({ success: true, changes: info.changes });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Delete item
app.delete('/api/items/:id', authenticateToken, (req, res) => {
    const { id } = req.params;
    try {
        const stmt = db.prepare('DELETE FROM items WHERE id = ?');
        stmt.run(id);
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Catch-all handler for any request that doesn't match one above
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../client/dist/index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on port ${PORT}`);
    try {
        const genAIVersion = require('@google/generative-ai/package.json').version;
        console.log(`Google Generative AI SDK Version: ${genAIVersion}`);
    } catch (e) {
        console.log('Could not determine Google Generative AI SDK version');
    }
});
